  <p align="center">  
  <a href="https://i.ibb.co/7YGn5qS/20230305-135924.jpg">
    <img alt="secktor docs" height="300" src="https://i.ibb.co/7YGn5qS/20230305-135924.jpg">
    <h1 align="center"> PRABATH-MD </h1>
  </a>
</p>  
<p align="center">
  <a aria-label="Join our chats" href="https://chat.whatsapp.com/KwFkWjI8qJ6B174esar8IM" target="_blank">
    <img alt="whatsapp" src="https://img.shields.io/badge/Join Group-25D366?style=for-the-badge&logo=whatsapp&logoColor=white" />
  </a>
  <a aria-label="Secktor is free to use" href="https://github.com/SamPandey001/Secktor-Md/blob/main/LICENCE" target="_blank">
    <img alt="License: GPL-3" src="https://badges.frapsoft.com/os/gpl/gpl.png?v=103)](https://opensource.org/licenses/GPL-3.0/" target="_blank" />
  </a>

</p>

---

<p align="center"><img src="https://profile-counter.glitch.me/{prabathLK}/count.svg" alt="prabathLK :: Visitor's Count" /></p>

  <p align="center"> 🔴 This is a whatsapp bot created based on Secktor-md whatsapp bot.  </p

  

---

![repo views](https://hits.seeyoufarm.com/api/count/incr/badge.svg?url=https%3A%2F%2Fgithub.com%2FprabathLK%2FPRABATH_MD&count_bg=%2379C83D&title_bg=%23555555&icon=gitpod.svg&icon_color=%23E7E7E7&title=Views&edge_flat=false)

![forks](https://img.shields.io/github/forks/prabathLK/PRABATH_MD?label=Forks&style=social)

![stars](https://img.shields.io/github/stars/prabathLK/PRABATH_MD?style=social)

  

 ## DEPLOYMENT METHODS

 

 <a><img src='https://i.imgur.com/LyHic3i.gif'/></a>

  

●. ***[SCAN QR CODE SERVER 1](https://prabath-md-qr.herokuapp.com/)***

●. ***[SCAN QR CODE SERVER 2](https://prabath-md-slstatus384.koyeb.app/)***

●. ***Get a Mongodb uri from [Clever-Cloud](https://api.clever-cloud.com/v2/session/login).***

●. ***Get a Mongodb uri from [railway.app](https://railway.app).***

●.  ***Click [FORK](https://github.com/prabathLK/PRABATH-MD/fork)***

---

[![Deploy to Koyeb](https://www.koyeb.com/static/images/deploy/button.svg)](https://app.koyeb.com/apps/deploy?type=git&repository=github.com/prabathLK/PRABATH_MD&branch=main&env[SESSION_ID]&env[OWNER_NUMBER]=94762280384&env[MONGODB_URI]&&env[OWNER_NAME]=prabath&env[KOYEB_API]&env[PREFIX]=.&env[BOTCAHX_API]&env[ALIVE_IMG]=https://telegra.ph/file/0ff686352c51b20af8231.jpg&env[ALIVE_MSJ]=IAmOnline&env[global_url]=instagram.com&env[FAKE_COUNTRY_CODE]=92&env[READ_MESSAGE]=false&env[DISABLE_PM]=false&env[WORKTYPE]=public&env[THEME]=PRABATH-MD&env[AUTO_STICKER]=false&env[AUTO_VOICE]=false&env[PACK_INFO]=prabath;madebyprabathmd&name=prabath-md&env[KOYEB_NAME]=prabath-md&env[ANTILINK_VALUES]=chat.whatsapp.com&env[PORT]=8000)

[![Deploy on Railway](https://railway.app/button.svg)](https://railway.app/template/NO4jvb?referralCode=iM43z3)

[![Deploy on heroku](https://www.herokucdn.com/deploy/button.svg)](https://dashboard.heroku.com/new?button-url=https://github.com/PrabathLK/PRABATH_MD&template=https://github.com/PrabathLK/PRABATH_MD.git)

  

 ## [Deploy on VPS or PC.](https://github.com/prabathLK/PRABATH_MD/blob/main/deploy-on-vps.md)

 


 ---

## License

The prabath-md is made available under the [GPL-3 license](https://github.com/SamPandey001/Secktor-Md/blob/main/LICENCE). 
